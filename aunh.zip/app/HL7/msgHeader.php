<?php 
namespace App\HL7;
class msgHeader {
  public $SendingApplication; // string
  public $SendingFacility; // string
  public $ReceivingApplication; // string
  public $ReceivingFacility; // string
}
