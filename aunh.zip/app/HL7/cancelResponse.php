<?php
namespace App\HL7;
class cancelResponse {
  public $return; // string
}