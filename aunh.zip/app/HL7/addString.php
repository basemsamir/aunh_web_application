<?php
namespace App\HL7;
class addString {
  public $Header; // string
  public $Order; // string
  public $Patient; // string
  public $Procedure; // string
}