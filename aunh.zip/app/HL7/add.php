<?php
namespace App\HL7;
class add {
  public $arg0; // msgHeader
  public $arg1; // orcOrderInfo
  public $arg2; // patientInfo
  public $arg3; // procedureInfo
}