<?php
namespace App\HL7;
class EditResponse {
  public $return; // string
}

