<?php
namespace App\HL7;
public class addResponse {
  public $return; // string
}