<?php 
namespace App\HL7;
class orcOrderInfo {
  public $StudyID; // string
  public $AccesstionNumber; // string
  public $ReceptionistID; // string
  public $LastNamefamilynameR; // string
  public $FirstNameR; // string
  public $MiddleNameR; // string
  public $DoctorID; // string
  public $LastNamefamilynameDoctor; // string
  public $FirstNameDoctor; // string
  public $MiddleNameDoctor; // string
  public $ModalityType; // string
  public $ModalityName; // string
}
