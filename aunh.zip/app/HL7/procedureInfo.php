<?php 
namespace App\HL7;
class procedureInfo {
  public $ProcedureID; // string
  public $ProcedureName; // string
  public $ProcedureReason; // string
  public $SceduledDateTime; // dateTime
  public $StudyID; // string
  public $AccesstionNumber; // string
  public $DoctorID; // string
  public $LastNamefamilynameDoctor; // string
  public $FirstNameDoctor; // string
  public $MiddleNameDoctor; // string

}
