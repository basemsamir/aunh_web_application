<?php 
namespace App\HL7;
class patientInfo {
  public $PatientID; // string
  public $PatientBirthdate; // dateTime
  public $PatientGender; // string
  public $LastNamefamilyname; // string
  public $FirstName; // string
  public $MiddleName; // string
  public $Address; // string
  public $PhoneNumber; // string
  public $MaritalStatus; // string
  public $Religion; // string
  public $NationalID; // string
  public $Nationality; // string

}