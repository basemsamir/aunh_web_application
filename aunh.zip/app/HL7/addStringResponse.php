<?php
namespace App\HL7;
use App\HL7\addResponse;
class addStringResponse {
  public $return; // string
}
