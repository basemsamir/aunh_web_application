var app = new Vue({
  el: '.container',
  data: {
    message: 'Hello Vue!'
  }
})