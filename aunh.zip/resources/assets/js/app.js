import Vue from 'vue'

new Vue({
  el: 'app_vue',
  data: {
  message: 'Hello Vue World!'
  }
})