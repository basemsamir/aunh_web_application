<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Flash Message Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'success' => 'The operation is done successfully',
    'failed' => 'There is something is wrong. Please try again',

];
