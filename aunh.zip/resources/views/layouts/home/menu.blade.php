<li class="@if(isset($patient_active)) {{ 'active '}} @endif"><a href="{{ url('patients') }}">Patients</a></li>
